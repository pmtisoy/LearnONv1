import { useState } from 'react'
import './App.css'

import Header from './components/Header'
import StatCard from './components/StatCard'
import ContinueLearning from './components/ContinueLearning'
import MilestoneCard from './components/MilestoneCard'
import BottomNav from './components/BottomNav'

import {
  user,
  stats,
  currentCourse,
  milestones,
} from './data/dashboardData'

function App() {
  return (
    <div className="app">
      <main className="dashboard">
        <Header userName={user.name} />

        <section
          className="stats-grid"
          aria-label="Learning statistics"
        >
          {stats.map((stat) => (
            <StatCard
              key={stat.id}
              icon={stat.icon}
              value={stat.value}
              label={stat.label}
            />
          ))}
        </section>

        <div className="dashboard-content-grid">
          <ContinueLearning course={currentCourse} />

          <section className="dashboard-section milestones-section">
            <div className="section-heading">
              <div>
                <p className="section-eyebrow">
                  This Week's Milestones
                </p>

                <h2>Keep the momentum going</h2>
              </div>
            </div>

            <div className="milestone-list">
              {milestones.map((milestone) => (
                <MilestoneCard
                  key={milestone.id}
                  icon={milestone.icon}
                  title={milestone.title}
                  description={milestone.description}
                  progress={milestone.progress}
                />
              ))}
            </div>
          </section>
        </div>
      </main>

      <BottomNav />
    </div>
  )
}

export default App