function Header({ userName }) {
  return (
    <header className="dashboard-header">
      <div>
        <p className="app-name">LearnON</p>

        <h1>
          Hi, {userName} <span aria-hidden="true">👋</span>
        </h1>

        <p className="header-subtitle">
          Keep learning and maintain your streak.
        </p>
      </div>

      <button
        type="button"
        className="profile-button"
        aria-label="Open profile"
      >
        M
      </button>
    </header>
  )
}

export default Header